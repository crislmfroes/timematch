// Array que armazena os eventos
let eventos = [];

// Função para criar um novo evento
function criarEvento() {
    // Obtém o nome do evento do campo de entrada
    const nomeEvento = document.getElementById('eventoNome').value;

    // Verifica se o nome do evento não está vazio
    if (nomeEvento.trim() !== '') {
        // Obtém a data e hora atuais
        const dataHoraAtual = new Date();
        const horaFormatada = `${dataHoraAtual.getHours()}:${padZero(dataHoraAtual.getMinutes())}`;
        const dataFormatada = `${dataHoraAtual.toLocaleDateString()} ${horaFormatada}`;

        // Adiciona o evento ao array
        eventos.push({ nome: nomeEvento, data: dataFormatada });

        // Exibe os eventos na lista
        exibirEventos();

        // Limpa o campo de entrada
        limparCampo();
    }
}

// Função para exibir os eventos na lista em ordem decrescente
function exibirEventos() {
    // Obtém a lista de eventos
    const listaEventos = document.getElementById('listaEventos');
    // Limpa o conteúdo da lista
    listaEventos.innerHTML = '';

    // Itera sobre os eventos em ordem decrescente e cria elementos HTML para cada um
    for (let index = eventos.length - 1; index >= 0; index--) {
        const evento = eventos[index];

        // Cria um elemento div para representar o cartão do evento
        const card = document.createElement('div');
        card.className = 'card';

        // Cria um elemento p para o nome do evento
        const nomeEvento = document.createElement('p');
        nomeEvento.className = 'nome-evento';
        nomeEvento.textContent = evento.nome;
        card.appendChild(nomeEvento);

        // Cria um elemento p para a data do evento
        const dataEvento = document.createElement('p');
        dataEvento.textContent = `Criado em: ${evento.data}`;
        card.appendChild(dataEvento);

        // Cria botões de editar e excluir
        const btnEditar = document.createElement('button');
        btnEditar.textContent = 'Editar';
        btnEditar.className = 'edit';
        btnEditar.onclick = () => editarEvento(index);
        card.appendChild(btnEditar);

        const btnExcluir = document.createElement('button');
        btnExcluir.textContent = 'Excluir';
        btnExcluir.className = 'delete';
        btnExcluir.onclick = () => excluirEvento(index);
        card.appendChild(btnExcluir);

        // Adiciona o cartão à lista de eventos
        listaEventos.appendChild(card);
    }
}

// Função para editar um evento
function editarEvento(index) {
    const novoNome = prompt('Digite o novo nome do evento:');
    if (novoNome !== null) {
        eventos[index].nome = novoNome;
        exibirEventos();
    }
}

// Função para excluir um evento
function excluirEvento(index) {
    eventos.splice(index, 1);
    exibirEventos();
}

// Função para limpar o campo de entrada
function limparCampo() {
    document.getElementById('eventoNome').value = '';
}

// Função auxiliar para adicionar zero à esquerda de um número, se necessário
function padZero(number) {
    return number < 10 ? '0' + number : number;
}

// Inicializa a exibição dos eventos ao carregar a página
exibirEventos();
