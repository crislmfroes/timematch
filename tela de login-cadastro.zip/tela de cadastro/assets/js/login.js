// Seleciona o elemento com a classe 'fa-eye' (presumivelmente um ícone de olho)
let btn = document.querySelector('.fa-eye');

// Adiciona um ouvinte de evento de clique ao ícone de olho
btn.addEventListener('click', () => {
  // Seleciona o elemento de entrada de senha pelo ID
  let inputSenha = document.querySelector('#senha');

  // Alterna entre os tipos de entrada 'password' e 'text' ao clicar no ícone de olho
  if (inputSenha.getAttribute('type') == 'password') {
    inputSenha.setAttribute('type', 'text');
  } else {
    inputSenha.setAttribute('type', 'password');
  }
});

// Função chamada ao tentar fazer login
function entrar() {
  // Seleciona os elementos do formulário pelo ID
  let usuario = document.querySelector('#usuario');
  let userLabel = document.querySelector('#userLabel');

  let senha = document.querySelector('#senha');
  let senhaLabel = document.querySelector('#senhaLabel');

  let msgError = document.querySelector('#msgError');
  let listaUser = [];

  // Objeto para armazenar informações do usuário validado
  let userValid = {
    nome: '',
    user: '',
    senha: ''
  };

  // Obtém a lista de usuários armazenada no localStorage
  listaUser = JSON.parse(localStorage.getItem('listaUser'));

  // Itera sobre a lista de usuários para encontrar uma correspondência
  listaUser.forEach((item) => {
    if (usuario.value == item.userCad && senha.value == item.senhaCad) {
      // Preenche o objeto userValid com as informações do usuário validado
      userValid = {
        nome: item.nomeCad,
        user: item.userCad,
        senha: item.senhaCad
      };
    }
  });

  // Verifica se as credenciais fornecidas correspondem a um usuário válido
  if (usuario.value == userValid.user && senha.value == userValid.senha) {
    // Redireciona para a página inicial
    window.location.href = '../../index.html';

    // Gera um token aleatório e o armazena no localStorage
    let mathRandom = Math.random().toString(16).substr(2);
    let token = mathRandom + mathRandom;
    localStorage.setItem('token', token);

    // Armazena as informações do usuário validado no localStorage
    localStorage.setItem('userLogado', JSON.stringify(userValid));
  } else {
    // Estiliza os elementos do formulário para indicar erro de login
    userLabel.setAttribute('style', 'color: red');
    usuario.setAttribute('style', 'border-color: red');
    senhaLabel.setAttribute('style', 'color: red');
    senha.setAttribute('style', 'border-color: red');
    msgError.setAttribute('style', 'display: block');
    msgError.innerHTML = 'Usuário ou senha incorretos';
    usuario.focus();
  }
}
