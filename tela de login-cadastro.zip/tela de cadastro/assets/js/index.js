// Verifica se o token de autenticação está ausente no armazenamento local
if (localStorage.getItem("token") == null) {
    // Exibe um alerta informando que o usuário precisa estar logado
    alert("Você precisa estar logado para acessar essa página");
  
    // Redireciona para a página de login
    window.location.href = "./assets/html/login.html";
  }
  
  // Obtém as informações do usuário armazenadas no localStorage e converte para objeto JavaScript
  const userLogado = JSON.parse(localStorage.getItem("userLogado"));
  
  // Seleciona o elemento com o ID "logado"
  const logado = document.querySelector("#logado");
  
  // Define o conteúdo do elemento logado com uma saudação usando o nome do usuário
  logado.innerHTML = `Olá ${userLogado.nome}`;
  
  // Função chamada quando o botão "Sair" é clicado
  function sair() {
    // Remove o token de autenticação e as informações do usuário do localStorage
    localStorage.removeItem("token");
    localStorage.removeItem("userLogado");
  
    // Redireciona para a página de login
    window.location.href = "./assets/html/login.html";
  }
  